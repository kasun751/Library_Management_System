import React from 'react'

function Protected() {
  return (
    <div>Protected</div>
  )
}

export default Protected